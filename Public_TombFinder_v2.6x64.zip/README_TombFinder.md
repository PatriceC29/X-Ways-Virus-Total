# TombFinder

# Documentation
### C++, VisualStudio 2017 Community

### Libraries Used:
*	[curl]() - curl-vc141-dynamic-x86_64.7.59.0
*	[jsoncpp]() - jsoncpp-vc140-static-32_64.1.8.0
*	[openssl]() - openssl-vc141-static-x86_64.1.0.2

### Used it:
	0. Take the archive and unpack this in the directory which you add the X-Tension
	1. Check if the file "conf.ini" exist
	2. Launch the X-Tension


























